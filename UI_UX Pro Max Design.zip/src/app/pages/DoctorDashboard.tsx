import * as React from "react";
import { AppShell } from "../components/ierbms/Navigation";
import { StatCard } from "../components/ierbms/StatCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ierbms/Card";
import { Button } from "../components/ierbms/Button";
import { StatusBadge } from "../components/ierbms/StatusBadge";
import { Users, Activity, Clock, FileText, Stethoscope } from "lucide-react";
import { useRealTime } from "../components/ierbms/RealTimeProvider";

export const DoctorDashboard: React.FC = () => {
  const { emergencies } = useRealTime();
  const incomingPatients = emergencies.filter(e => e.status === "in-transit");
  const assignedPatients = [
    { id: "P-101", name: "Sarah Johnson", condition: "Cardiac Monitoring", bed: "ICU-3", status: "critical" as const },
    { id: "P-102", name: "Michael Brown", condition: "Post-Surgery Recovery", bed: "Ward A-12", status: "stable" as const },
    { id: "P-103", name: "Lisa Anderson", condition: "Respiratory Support", bed: "ICU-7", status: "moderate" as const },
  ];

  return (
    <AppShell role="doctor" userName="Dr. Kwame Boateng">
      <div className="space-y-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Assigned Patients"
            value={assignedPatients.length}
            icon={Users}
            variant="default"
          />
          <StatCard
            title="Incoming Cases"
            value={incomingPatients.length}
            icon={Activity}
            variant="warning"
          />
          <StatCard
            title="Consultations Today"
            value={8}
            icon={Stethoscope}
            variant="success"
          />
          <StatCard
            title="Avg Treatment Time"
            value="45 min"
            icon={Clock}
            variant="default"
          />
        </div>

        {/* Incoming Emergencies */}
        <Card>
          <CardHeader>
            <CardTitle>Incoming Emergency Patients</CardTitle>
            <CardDescription>Prepare for arriving critical cases</CardDescription>
          </CardHeader>
          <CardContent>
            {incomingPatients.length > 0 ? (
              <div className="space-y-4">
                {incomingPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className="p-4 border rounded-lg bg-[var(--accent)]"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold">{patient.patientName}</h4>
                          <StatusBadge status={patient.severity} pulse>
                            {patient.severity.toUpperCase()}
                          </StatusBadge>
                        </div>
                        <p className="text-sm text-muted-foreground">{patient.emergencyType}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-[var(--primary)]">ETA: {patient.eta || "N/A"}</p>
                        <p className="text-xs text-muted-foreground">{patient.id}</p>
                      </div>
                    </div>

                    {patient.vitalSigns && (
                      <div className="grid grid-cols-4 gap-3 p-3 bg-background rounded-lg mb-3">
                        <div>
                          <p className="text-xs text-muted-foreground">Heart Rate</p>
                          <p className="text-sm font-semibold">{patient.vitalSigns.heartRate} bpm</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Blood Pressure</p>
                          <p className="text-sm font-semibold">{patient.vitalSigns.bloodPressure}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">SpO2</p>
                          <p className="text-sm font-semibold">{patient.vitalSigns.oxygenSaturation}%</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Temperature</p>
                          <p className="text-sm font-semibold">{patient.vitalSigns.temperature}°C</p>
                        </div>
                      </div>
                    )}

                    <Button variant="primary" size="sm" className="w-full">
                      <FileText className="h-4 w-4" />
                      Review Case Details
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No incoming emergency patients</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Assigned Patients */}
        <Card>
          <CardHeader>
            <CardTitle>Your Assigned Patients</CardTitle>
            <CardDescription>Currently under your care</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {assignedPatients.map((patient) => (
                <div
                  key={patient.id}
                  className="p-4 border rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{patient.name}</h4>
                        <StatusBadge status={patient.status}>
                          {patient.status.toUpperCase()}
                        </StatusBadge>
                      </div>
                      <p className="text-sm text-muted-foreground">{patient.condition}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{patient.bed}</p>
                      <p className="text-xs text-muted-foreground">{patient.id}</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="primary" size="sm" className="flex-1">
                      View Records
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      Add Notes
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Treatment Queue */}
        <Card>
          <CardHeader>
            <CardTitle>Treatment Queue</CardTitle>
            <CardDescription>Pending consultations and procedures</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { patient: "James Wilson", procedure: "Post-op Checkup", time: "10:30 AM", priority: "moderate" as const },
                { patient: "Emma Davis", procedure: "Blood Test Review", time: "11:00 AM", priority: "stable" as const },
                { patient: "Robert Taylor", procedure: "X-Ray Consultation", time: "11:30 AM", priority: "stable" as const },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 border rounded-lg flex items-center justify-between hover:bg-accent transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-[var(--primary)] flex items-center justify-center text-white font-semibold">
                      {item.patient.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium">{item.patient}</p>
                      <p className="text-sm text-muted-foreground">{item.procedure}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <StatusBadge status={item.priority}>
                      {item.priority.toUpperCase()}
                    </StatusBadge>
                    <p className="text-sm font-medium">{item.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
};