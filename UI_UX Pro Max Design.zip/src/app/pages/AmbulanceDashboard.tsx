import * as React from "react";
import { AppShell } from "../components/ierbms/Navigation";
import { StatCard } from "../components/ierbms/StatCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ierbms/Card";
import { Button } from "../components/ierbms/Button";
import { StatusBadge } from "../components/ierbms/StatusBadge";
import { Activity, Clock, MapPin, Navigation, AlertCircle, Plus, Wifi, WifiOff } from "lucide-react";
import { useRealTime } from "../components/ierbms/RealTimeProvider";
import { useNavigate } from "react-router";

export const AmbulanceDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { emergencies, hospitals, connected } = useRealTime();
  const activeEmergencies = emergencies.filter(e => e.status === "active" || e.status === "in-transit");

  return (
    <AppShell role="ambulance" userName="Samuel Osei">
      <div className="space-y-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Active Cases"
            value={activeEmergencies.length}
            icon={Activity}
            variant="default"
          />
          <StatCard
            title="Today's Emergencies"
            value={12}
            icon={AlertCircle}
            variant="warning"
            trend={{ value: 8, isPositive: false }}
          />
          <StatCard
            title="Avg Response Time"
            value="8.5 min"
            icon={Clock}
            variant="success"
            trend={{ value: 12, isPositive: true }}
          />
          <StatCard
            title="Total Distance"
            value="156 km"
            icon={MapPin}
            variant="default"
          />
        </div>

        {/* Quick Action */}
        <Card className="border-[var(--primary)] bg-[var(--accent)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold mb-1">New Emergency</h3>
                <p className="text-sm text-muted-foreground">
                  Report a new emergency and get AI-powered hospital recommendations
                </p>
              </div>
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate("/ambulance/new-emergency")}
              >
                <Plus className="h-5 w-5" />
                Create Emergency
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Active Emergencies */}
        <Card>
          <CardHeader>
            <CardTitle>Active Emergencies</CardTitle>
            <CardDescription>Currently assigned emergency cases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeEmergencies.map((emergency) => (
                <div
                  key={emergency.id}
                  className="p-4 border rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{emergency.patientName}</h4>
                        <StatusBadge status={emergency.severity} pulse={emergency.severity === "critical"}>
                          {emergency.severity.toUpperCase()}
                        </StatusBadge>
                      </div>
                      <p className="text-sm text-muted-foreground">{emergency.emergencyType}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {emergency.id}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Location</p>
                      <p className="text-sm flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {emergency.location.address}
                      </p>
                    </div>
                    {emergency.assignedHospital && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Hospital</p>
                        <p className="text-sm">{emergency.assignedHospital}</p>
                      </div>
                    )}
                  </div>

                  {emergency.vitalSigns && (
                    <div className="grid grid-cols-4 gap-3 p-3 bg-muted rounded-lg mb-3">
                      <div>
                        <p className="text-xs text-muted-foreground">HR</p>
                        <p className="text-sm font-semibold">{emergency.vitalSigns.heartRate} bpm</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">BP</p>
                        <p className="text-sm font-semibold">{emergency.vitalSigns.bloodPressure}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">SpO2</p>
                        <p className="text-sm font-semibold">{emergency.vitalSigns.oxygenSaturation}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Temp</p>
                        <p className="text-sm font-semibold">{emergency.vitalSigns.temperature}°C</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {emergency.status === "in-transit" ? `ETA: ${emergency.eta}` : "Awaiting dispatch"}
                    </span>
                    <Button variant="outline" size="sm">
                      <Navigation className="h-4 w-4" />
                      Navigate
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recommended Hospitals */}
        <Card>
          <CardHeader>
            <CardTitle>Nearby Hospitals</CardTitle>
            <CardDescription>AI-recommended hospitals based on current location</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {hospitals.slice(0, 3).map((hospital) => (
                <div
                  key={hospital.id}
                  className="p-4 border rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">{hospital.name}</h4>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {hospital.distance} km away
                      </p>
                    </div>
                    {hospital.score && (
                      <div className="text-right">
                        <div className="text-2xl font-bold text-[var(--primary)]">{hospital.score}</div>
                        <p className="text-xs text-muted-foreground">Match Score</p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-3 mt-3">
                    <div className="text-center p-2 bg-muted rounded">
                      <p className="text-sm font-semibold">{hospital.availableBeds}</p>
                      <p className="text-xs text-muted-foreground">Beds</p>
                    </div>
                    <div className="text-center p-2 bg-muted rounded">
                      <p className="text-sm font-semibold">{hospital.icuBeds.available}</p>
                      <p className="text-xs text-muted-foreground">ICU</p>
                    </div>
                    <div className="text-center p-2 bg-muted rounded">
                      <p className="text-sm font-semibold">{hospital.specialists.length}</p>
                      <p className="text-xs text-muted-foreground">Specialists</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
};