import * as React from "react";
import { useNavigate } from "react-router";
import { AppShell } from "../components/ierbms/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ierbms/Card";
import { Button } from "../components/ierbms/Button";
import { Input } from "../components/ierbms/Input";
import { StatusBadge } from "../components/ierbms/StatusBadge";
import { MapPin, User, Activity, AlertCircle, Hospital, CheckCircle } from "lucide-react";
import { mockHospitals } from "../utils/mockData";

export const NewEmergency: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = React.useState({
    patientName: "",
    emergencyType: "",
    severity: "moderate" as "critical" | "moderate" | "stable",
    location: "",
    heartRate: "",
    bloodPressure: "",
    oxygenSaturation: "",
    temperature: "",
  });

  const [showRecommendations, setShowRecommendations] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowRecommendations(true);
  };

  const handleConfirmHospital = () => {
    navigate("/ambulance");
  };

  return (
    <AppShell role="ambulance" userName="Samuel Osei">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">New Emergency</h1>
          <p className="text-muted-foreground">
            Enter patient information to receive AI-powered hospital recommendations
          </p>
        </div>

        {!showRecommendations ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Patient Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Patient Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Patient Name</label>
                  <Input
                    placeholder="Enter patient name"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Emergency Type</label>
                  <select
                    className="flex h-10 w-full rounded-lg border border-input bg-input-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring transition-all"
                    value={formData.emergencyType}
                    onChange={(e) => setFormData({ ...formData, emergencyType: e.target.value })}
                    required
                  >
                    <option value="">Select emergency type</option>
                    <option value="Cardiac Arrest">Cardiac Arrest</option>
                    <option value="Road Traffic Accident">Road Traffic Accident</option>
                    <option value="Stroke">Stroke</option>
                    <option value="Respiratory Distress">Respiratory Distress</option>
                    <option value="Trauma">Trauma</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Severity Level</label>
                  <div className="flex gap-3">
                    {(["stable", "moderate", "critical"] as const).map((severity) => (
                      <button
                        key={severity}
                        type="button"
                        onClick={() => setFormData({ ...formData, severity })}
                        className={`flex-1 p-3 rounded-lg border-2 transition-all ${
                          formData.severity === severity
                            ? "border-[var(--primary)] bg-[var(--accent)]"
                            : "border-border hover:border-[var(--primary)]/50"
                        }`}
                      >
                        <StatusBadge status={severity} className="mx-auto">
                          {severity.toUpperCase()}
                        </StatusBadge>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Current location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Vital Signs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Vital Signs
                </CardTitle>
                <CardDescription>Enter current patient vital signs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Heart Rate (bpm)</label>
                    <Input
                      type="number"
                      placeholder="e.g., 80"
                      value={formData.heartRate}
                      onChange={(e) => setFormData({ ...formData, heartRate: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Blood Pressure</label>
                    <Input
                      placeholder="e.g., 120/80"
                      value={formData.bloodPressure}
                      onChange={(e) => setFormData({ ...formData, bloodPressure: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Oxygen Saturation (%)</label>
                    <Input
                      type="number"
                      placeholder="e.g., 98"
                      value={formData.oxygenSaturation}
                      onChange={(e) => setFormData({ ...formData, oxygenSaturation: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Temperature (°C)</label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="e.g., 37.0"
                      value={formData.temperature}
                      onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => navigate("/ambulance")}
              >
                Cancel
              </Button>
              <Button type="submit" variant="primary" className="flex-1">
                <AlertCircle className="h-4 w-4" />
                Get Hospital Recommendations
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            {/* Success Alert */}
            <Card className="border-[var(--success)] bg-[var(--success)]/10">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-[var(--success)]" />
                  <div className="flex-1">
                    <h4 className="font-semibold">Emergency Case Created</h4>
                    <p className="text-sm text-muted-foreground">
                      AI analysis complete. Here are the recommended hospitals based on patient condition and availability.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recommended Hospitals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hospital className="h-5 w-5" />
                  Recommended Hospitals
                </CardTitle>
                <CardDescription>
                  Ranked by AI based on severity, distance, bed availability, and specialist availability
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockHospitals.slice(0, 3).map((hospital, idx) => (
                    <div
                      key={hospital.id}
                      className={`p-6 border-2 rounded-lg transition-all ${
                        idx === 0
                          ? "border-[var(--success)] bg-[var(--success)]/5"
                          : "border-border hover:border-[var(--primary)]"
                      }`}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            {idx === 0 && (
                              <span className="inline-flex items-center justify-center h-6 w-6 bg-[var(--success)] text-white rounded-full text-xs font-bold">
                                ✓
                              </span>
                            )}
                            <h3 className="text-xl font-semibold">{hospital.name}</h3>
                          </div>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {hospital.location.address} • {hospital.distance} km away
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-3xl font-bold text-[var(--primary)]">{hospital.score}</div>
                          <p className="text-xs text-muted-foreground">Match Score</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-3 mb-4">
                        <div className="text-center p-3 bg-muted rounded-lg">
                          <p className="text-lg font-semibold">{hospital.availableBeds}</p>
                          <p className="text-xs text-muted-foreground">Available Beds</p>
                        </div>
                        <div className="text-center p-3 bg-muted rounded-lg">
                          <p className="text-lg font-semibold">{hospital.icuBeds.available}</p>
                          <p className="text-xs text-muted-foreground">ICU Beds</p>
                        </div>
                        <div className="text-center p-3 bg-muted rounded-lg">
                          <p className="text-lg font-semibold">{hospital.specialists.length}</p>
                          <p className="text-xs text-muted-foreground">Specialists</p>
                        </div>
                        <div className="text-center p-3 bg-muted rounded-lg">
                          <p className="text-lg font-semibold">{Math.round((hospital.distance || 0) * 1.5)}</p>
                          <p className="text-xs text-muted-foreground">ETA (min)</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {hospital.specialists.map((specialist, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center px-3 py-1 rounded-full bg-[var(--accent)] text-xs"
                          >
                            {specialist}
                          </span>
                        ))}
                      </div>

                      {idx === 0 && (
                        <Button
                          variant="success"
                          className="w-full"
                          onClick={handleConfirmHospital}
                        >
                          <CheckCircle className="h-4 w-4" />
                          Confirm & Navigate to Hospital
                        </Button>
                      )}
                      {idx > 0 && (
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={handleConfirmHospital}
                        >
                          Select This Hospital
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowRecommendations(false)}
              >
                Back to Form
              </Button>
              <Button
                variant="primary"
                className="flex-1"
                onClick={() => navigate("/ambulance")}
              >
                Return to Dashboard
              </Button>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
};
