import * as React from "react";
import { AppShell } from "../components/ierbms/Navigation";
import { StatCard } from "../components/ierbms/StatCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ierbms/Card";
import { StatusBadge } from "../components/ierbms/StatusBadge";
import { Ambulance, Hospital, Activity, MapPin, Users, Clock } from "lucide-react";
import { useRealTime } from "../components/ierbms/RealTimeProvider";
import { chartData } from "../utils/mockData";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";

export const CommandCenterDashboard: React.FC = () => {
  const { emergencies, hospitals, ambulances } = useRealTime();
  const activeEmergencies = emergencies.filter(e => e.status !== "completed");
  const availableAmbulances = ambulances.filter(a => a.status === "available");
  const totalBeds = hospitals.reduce((sum, h) => sum + h.availableBeds, 0);

  const COLORS = ["#F44336", "#FF9800", "#2196F3", "#4CAF50", "#9C27B0"];

  return (
    <AppShell role="command" userName="Chief Commander Agyeman">
      <div className="space-y-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Active Emergencies"
            value={activeEmergencies.length}
            icon={Activity}
            variant="danger"
            trend={{ value: 5, isPositive: false }}
          />
          <StatCard
            title="Available Ambulances"
            value={availableAmbulances.length}
            icon={Ambulance}
            variant="success"
          />
          <StatCard
            title="Total Available Beds"
            value={totalBeds}
            icon={Hospital}
            variant="default"
          />
          <StatCard
            title="Avg Response Time"
            value="9.2 min"
            icon={Clock}
            variant="warning"
            trend={{ value: 8, isPositive: true }}
          />
        </div>

        {/* Live Emergency Map */}
        <Card>
          <CardHeader>
            <CardTitle>Live Emergency Map</CardTitle>
            <CardDescription>Real-time tracking of ambulances and emergencies across the city</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative h-96 bg-muted rounded-lg overflow-hidden">
              {/* Map placeholder with grid */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
                <div className="absolute inset-0" style={{
                  backgroundImage: `
                    linear-gradient(var(--border) 1px, transparent 1px),
                    linear-gradient(90deg, var(--border) 1px, transparent 1px)
                  `,
                  backgroundSize: '40px 40px'
                }} />
              </div>

              {/* Emergency markers */}
              {emergencies.slice(0, 3).map((emergency, idx) => (
                <div
                  key={emergency.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-pulse"
                  style={{
                    left: `${20 + idx * 25}%`,
                    top: `${30 + idx * 15}%`
                  }}
                >
                  <div className="relative">
                    <div className="h-6 w-6 bg-[var(--danger)] rounded-full border-2 border-white shadow-lg" />
                    <div className="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-white dark:bg-gray-800 px-2 py-1 rounded shadow-lg text-xs">
                      <StatusBadge status={emergency.severity} className="text-xs px-2 py-0.5">
                        {emergency.emergencyType}
                      </StatusBadge>
                    </div>
                  </div>
                </div>
              ))}

              {/* Ambulance markers */}
              {ambulances.slice(0, 4).map((ambulance, idx) => (
                <div
                  key={ambulance.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: `${30 + idx * 20}%`,
                    top: `${50 + idx * 10}%`
                  }}
                >
                  <div className="h-4 w-4 bg-[var(--primary)] rounded-full border-2 border-white shadow-lg" />
                </div>
              ))}

              {/* Hospital markers */}
              {hospitals.slice(0, 3).map((hospital, idx) => (
                <div
                  key={hospital.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: `${40 + idx * 15}%`,
                    top: `${40 + idx * 12}%`
                  }}
                >
                  <div className="h-8 w-8 bg-[var(--success)] rounded-lg border-2 border-white shadow-lg flex items-center justify-center">
                    <Hospital className="h-4 w-4 text-white" />
                  </div>
                </div>
              ))}

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 space-y-2">
                <div className="flex items-center gap-2 text-xs">
                  <div className="h-3 w-3 bg-[var(--danger)] rounded-full" />
                  <span>Emergency</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <div className="h-3 w-3 bg-[var(--primary)] rounded-full" />
                  <span>Ambulance</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <div className="h-3 w-3 bg-[var(--success)] rounded-lg" />
                  <span>Hospital</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Emergency Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Emergency Trends</CardTitle>
              <CardDescription>6-month emergency response overview</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData.emergencyTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="emergencies"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    name="Emergencies"
                  />
                  <Line
                    type="monotone"
                    dataKey="resolved"
                    stroke="var(--chart-2)"
                    strokeWidth={2}
                    name="Resolved"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Emergency Types Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Emergency Types</CardTitle>
              <CardDescription>Distribution by emergency category</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData.emergencyTypes}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ type, percentage }) => `${type} (${percentage}%)`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {chartData.emergencyTypes.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Hospital Utilization */}
          <Card>
            <CardHeader>
              <CardTitle>Hospital Bed Occupancy</CardTitle>
              <CardDescription>Current occupancy rates across hospitals</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData.bedOccupancy}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="occupancy" fill="var(--chart-1)">
                    {chartData.bedOccupancy.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.occupancy > 85 ? "var(--chart-4)" : "var(--chart-1)"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Response Time Analytics */}
          <Card>
            <CardHeader>
              <CardTitle>Response Time by Hour</CardTitle>
              <CardDescription>Average response times throughout the day</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData.responseTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="hour" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgTime"
                    stroke="var(--chart-3)"
                    strokeWidth={2}
                    name="Avg Time (min)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Ambulance Fleet Status */}
        <Card>
          <CardHeader>
            <CardTitle>Ambulance Fleet Status</CardTitle>
            <CardDescription>Real-time ambulance availability and assignments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {ambulances.map((ambulance) => (
                <div
                  key={ambulance.id}
                  className="p-4 border rounded-lg"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-[var(--primary)] flex items-center justify-center">
                        <Ambulance className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold">{ambulance.id}</p>
                        <p className="text-xs text-muted-foreground">{ambulance.plateNumber}</p>
                      </div>
                    </div>
                    <StatusBadge
                      status={
                        ambulance.status === "available" ? "stable" :
                        ambulance.status === "maintenance" ? "moderate" : "info"
                      }
                    >
                      {ambulance.status.toUpperCase()}
                    </StatusBadge>
                  </div>
                  {ambulance.assignedEmergency && (
                    <p className="text-sm text-muted-foreground">
                      Assigned: {ambulance.assignedEmergency}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
};