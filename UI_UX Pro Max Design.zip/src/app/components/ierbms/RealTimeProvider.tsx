import * as React from "react";
import { mockEmergencies, mockAmbulances, mockHospitals, type Emergency, type Ambulance, type Hospital } from "../../utils/mockData";

interface RealTimeContextType {
  emergencies: Emergency[];
  ambulances: Ambulance[];
  hospitals: Hospital[];
  connected: boolean;
}

const RealTimeContext = React.createContext<RealTimeContextType | undefined>(undefined);

export const useRealTime = () => {
  const context = React.useContext(RealTimeContext);
  if (!context) {
    throw new Error("useRealTime must be used within RealTimeProvider");
  }
  return context;
};

export const RealTimeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [emergencies, setEmergencies] = React.useState<Emergency[]>(mockEmergencies);
  const [ambulances, setAmbulances] = React.useState<Ambulance[]>(mockAmbulances);
  const [hospitals, setHospitals] = React.useState<Hospital[]>(mockHospitals);
  const [connected, setConnected] = React.useState(false);

  React.useEffect(() => {
    // Simulate connection
    setConnected(true);

    // Simulate real-time updates every 5 seconds
    const interval = setInterval(() => {
      setEmergencies(prev => {
        return prev.map(emergency => {
          // Randomly update vital signs for in-transit emergencies
          if (emergency.status === "in-transit" && emergency.vitalSigns) {
            const heartRateChange = Math.floor(Math.random() * 10) - 5;
            const spo2Change = Math.floor(Math.random() * 4) - 2;
            
            return {
              ...emergency,
              vitalSigns: {
                ...emergency.vitalSigns,
                heartRate: Math.max(60, Math.min(180, emergency.vitalSigns.heartRate + heartRateChange)),
                oxygenSaturation: Math.max(85, Math.min(100, emergency.vitalSigns.oxygenSaturation + spo2Change)),
              }
            };
          }
          return emergency;
        });
      });

      // Simulate ambulance movement
      setAmbulances(prev => {
        return prev.map(ambulance => {
          if (ambulance.status === "on-route" || ambulance.status === "engaged") {
            return {
              ...ambulance,
              location: {
                lat: ambulance.location.lat + (Math.random() * 0.001 - 0.0005),
                lng: ambulance.location.lng + (Math.random() * 0.001 - 0.0005),
              }
            };
          }
          return ambulance;
        });
      });

      // Simulate bed availability changes
      setHospitals(prev => {
        return prev.map(hospital => {
          const bedChange = Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : -1) : 0;
          const icuChange = Math.random() > 0.8 ? (Math.random() > 0.5 ? 1 : -1) : 0;
          
          return {
            ...hospital,
            availableBeds: Math.max(0, Math.min(hospital.totalBeds, hospital.availableBeds + bedChange)),
            icuBeds: {
              ...hospital.icuBeds,
              available: Math.max(0, Math.min(hospital.icuBeds.total, hospital.icuBeds.available + icuChange))
            }
          };
        });
      });
    }, 5000);

    return () => {
      clearInterval(interval);
      setConnected(false);
    };
  }, []);

  return (
    <RealTimeContext.Provider value={{ emergencies, ambulances, hospitals, connected }}>
      {children}
    </RealTimeContext.Provider>
  );
};