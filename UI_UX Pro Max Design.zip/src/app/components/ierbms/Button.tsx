import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../ui/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 font-medium",
  {
    variants: {
      variant: {
        primary: "bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary-hover)] focus-visible:ring-[var(--primary)] shadow-sm",
        secondary: "bg-[var(--secondary)] text-[var(--secondary-foreground)] hover:bg-[var(--secondary-hover)] focus-visible:ring-[var(--secondary)] shadow-sm",
        success: "bg-[var(--success)] text-[var(--success-foreground)] hover:bg-[var(--success-hover)] focus-visible:ring-[var(--success)] shadow-sm",
        warning: "bg-[var(--warning)] text-[var(--warning-foreground)] hover:bg-[var(--warning-hover)] focus-visible:ring-[var(--warning)] shadow-sm",
        danger: "bg-[var(--danger)] text-[var(--danger-foreground)] hover:bg-[var(--danger-hover)] focus-visible:ring-[var(--danger)] shadow-sm",
        info: "bg-[var(--info)] text-[var(--info-foreground)] hover:bg-[var(--info-hover)] focus-visible:ring-[var(--info)] shadow-sm",
        outline: "border-2 border-[var(--border)] bg-transparent hover:bg-[var(--accent)] focus-visible:ring-[var(--primary)]",
        ghost: "hover:bg-[var(--accent)] focus-visible:ring-[var(--primary)]",
        link: "text-[var(--primary)] underline-offset-4 hover:underline focus-visible:ring-0",
      },
      size: {
        sm: "h-8 px-3 text-sm",
        md: "h-10 px-4",
        lg: "h-12 px-6 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, disabled, children, ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={disabled || loading}
        {...props}
      >
        {loading && (
          <svg
            className="animate-spin h-4 w-4"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
        )}
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
