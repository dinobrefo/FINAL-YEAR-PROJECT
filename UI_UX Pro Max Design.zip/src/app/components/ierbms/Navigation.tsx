import * as React from "react";
import { Link, useLocation } from "react-router";
import { cn } from "../ui/utils";
import { useTheme } from "./ThemeProvider";
import {
  Activity,
  Ambulance,
  Bell,
  Hospital,
  LayoutDashboard,
  LogOut,
  Map,
  Settings,
  Users,
  FileText,
  Stethoscope,
  BedDouble,
  Moon,
  Sun,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const roleNavigationMap: Record<string, NavItem[]> = {
  ambulance: [
    { label: "Dashboard", href: "/ambulance", icon: LayoutDashboard },
    { label: "New Emergency", href: "/ambulance/new-emergency", icon: Activity },
    { label: "Active Cases", href: "/ambulance/cases", icon: FileText },
    { label: "Navigation", href: "/ambulance/navigation", icon: Map },
    { label: "History", href: "/ambulance/history", icon: FileText },
  ],
  hospital: [
    { label: "Dashboard", href: "/hospital", icon: LayoutDashboard },
    { label: "Bed Management", href: "/hospital/beds", icon: BedDouble },
    { label: "ICU Dashboard", href: "/hospital/icu", icon: Activity },
    { label: "Incoming", href: "/hospital/incoming", icon: Ambulance },
    { label: "Staff", href: "/hospital/staff", icon: Users },
  ],
  doctor: [
    { label: "Dashboard", href: "/doctor", icon: LayoutDashboard },
    { label: "Assigned Patients", href: "/doctor/patients", icon: Users },
    { label: "Incoming", href: "/doctor/incoming", icon: Activity },
    { label: "Treatment Queue", href: "/doctor/queue", icon: FileText },
    { label: "Records", href: "/doctor/records", icon: Stethoscope },
  ],
  nurse: [
    { label: "Dashboard", href: "/nurse", icon: LayoutDashboard },
    { label: "Admissions", href: "/nurse/admissions", icon: FileText },
    { label: "Bed Assignment", href: "/nurse/beds", icon: BedDouble },
    { label: "Ward Monitoring", href: "/nurse/wards", icon: Activity },
    { label: "Patients", href: "/nurse/patients", icon: Users },
  ],
  command: [
    { label: "Dashboard", href: "/command", icon: LayoutDashboard },
    { label: "Live Map", href: "/command/map", icon: Map },
    { label: "Ambulances", href: "/command/ambulances", icon: Ambulance },
    { label: "Hospitals", href: "/command/hospitals", icon: Hospital },
    { label: "Analytics", href: "/command/analytics", icon: Activity },
  ],
  authority: [
    { label: "Dashboard", href: "/authority", icon: LayoutDashboard },
    { label: "Statistics", href: "/authority/statistics", icon: Activity },
    { label: "Trends", href: "/authority/trends", icon: FileText },
    { label: "Forecasting", href: "/authority/forecasting", icon: Map },
    { label: "Reports", href: "/authority/reports", icon: FileText },
  ],
};

export interface NavigationProps {
  role: string;
  className?: string;
}

export const Navigation: React.FC<NavigationProps> = ({ role, className }) => {
  const location = useLocation();
  const navItems = roleNavigationMap[role] || [];

  return (
    <nav className={cn("flex flex-col gap-1 p-4", className)}>
      {navItems.map((item) => {
        const isActive = location.pathname === item.href;
        const Icon = item.icon;

        return (
          <Link
            key={item.href}
            to={item.href}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
              isActive
                ? "bg-[var(--primary)] text-white shadow-sm"
                : "text-foreground hover:bg-[var(--accent)] hover:text-[var(--accent-foreground)]"
            )}
          >
            <Icon className="h-5 w-5" />
            <span className="font-medium">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
};

export interface AppShellProps {
  role: string;
  userName: string;
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ role, userName, children }) => {
  const { theme, setTheme, effectiveTheme } = useTheme();
  const [showConnectionStatus, setShowConnectionStatus] = React.useState(true);

  const toggleTheme = () => {
    setTheme(effectiveTheme === "dark" ? "light" : "dark");
  };

  React.useEffect(() => {
    const timer = setTimeout(() => setShowConnectionStatus(false), 5000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-6 border-b">
          <h1 className="text-xl font-bold text-[var(--primary)]">IERBMS</h1>
          <p className="text-sm text-muted-foreground mt-1 capitalize">{role} Portal</p>
        </div>

        <div className="flex-1 overflow-y-auto">
          <Navigation role={role} />
        </div>

        <div className="p-4 border-t space-y-2">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-foreground hover:bg-accent transition-all"
          >
            {effectiveTheme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
            <span className="font-medium">
              {effectiveTheme === "dark" ? "Light Mode" : "Dark Mode"}
            </span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-foreground hover:bg-accent transition-all">
            <Bell className="h-5 w-5" />
            <span className="font-medium">Notifications</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-foreground hover:bg-accent transition-all">
            <Settings className="h-5 w-5" />
            <span className="font-medium">Settings</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-[var(--danger)] hover:bg-accent transition-all">
            <LogOut className="h-5 w-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        <header className="sticky top-0 z-10 bg-card border-b px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold">Welcome back, {userName}</h2>
              <p className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
            <div className="flex items-center gap-4">
              {showConnectionStatus && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-[var(--success)]/10 border border-[var(--success)] rounded-lg">
                  <div className="h-2 w-2 bg-[var(--success)] rounded-full animate-pulse" />
                  <span className="text-xs font-medium text-[var(--success)]">Real-time Connected</span>
                </div>
              )}
              <button className="relative p-2 rounded-lg hover:bg-accent transition-colors">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 h-2 w-2 bg-[var(--danger)] rounded-full"></span>
              </button>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-[var(--primary)] flex items-center justify-center text-white font-semibold">
                  {userName.charAt(0)}
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="p-8">{children}</div>
      </main>
    </div>
  );
};