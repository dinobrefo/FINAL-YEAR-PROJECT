import { RouterProvider } from 'react-router';
import { router } from './routes';
import { ThemeProvider } from './components/ierbms/ThemeProvider';
import { RealTimeProvider } from './components/ierbms/RealTimeProvider';

export default function App() {
  return (
    <ThemeProvider>
      <RealTimeProvider>
        <RouterProvider router={router} />
      </RealTimeProvider>
    </ThemeProvider>
  );
}