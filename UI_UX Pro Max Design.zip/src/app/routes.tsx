import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { AmbulanceDashboard } from "./pages/AmbulanceDashboard";
import { HospitalDashboard } from "./pages/HospitalDashboard";
import { DoctorDashboard } from "./pages/DoctorDashboard";
import { CommandCenterDashboard } from "./pages/CommandCenterDashboard";
import { NewEmergency } from "./pages/NewEmergency";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <LandingPage />,
  },
  {
    path: "/ambulance",
    element: <AmbulanceDashboard />,
  },
  {
    path: "/ambulance/new-emergency",
    element: <NewEmergency />,
  },
  {
    path: "/hospital",
    element: <HospitalDashboard />,
  },
  {
    path: "/doctor",
    element: <DoctorDashboard />,
  },
  {
    path: "/command",
    element: <CommandCenterDashboard />,
  },
  {
    path: "*",
    element: (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-[var(--primary)] mb-4">404</h1>
          <p className="text-xl text-muted-foreground mb-8">Page not found</p>
          <a
            href="/"
            className="inline-flex items-center justify-center px-6 py-3 rounded-lg bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)] transition-all"
          >
            Return Home
          </a>
        </div>
      </div>
    ),
  },
]);